#include "testLine.h"
#include "Queue.h"

using namespace std;

// testing enqueue on an empty queue
void TestLine::testEnqueue() {
    char lane = 'O';
    cout << "What lane is your customer entering?" << endl;
    cout << "E for express, R for regular: ";
    cin >> lane;
    if (lane == 'e') {
        lane = 'E';
    }
    else if (lane == 'r') {
        lane = 'R';
    }
    else if (lane != 'E') {
        if (lane != 'R') {
            cout << "Incorrect Input, try again later." << endl;
        }
    }
    // queue is empty
    Queue q;
    // placing node in the queue
    q.enqueue(1, 10, 20);
    // taking the one queue out of the node
    q.dequeue(lane);

    // Check if queue is empty
    if (!q.isEmpty(&q)) {
        success = false;
    }
    if (success) {
        cout << "\033[1;33mSuccessful test\033[0m" << endl;
    }
    else {
        cout << "\033[1;33mThe test was unsuccessful\033[0m" << endl;
    }
}

// testing dequeue with one node in the queue
void TestLine::testDequeue() {
    Queue q;
    char lane = 'O';
    cout << "What lane is your customer leaving?" << endl;
    cout << "E for express, R for regular: ";
    cin >> lane;
    if (lane == 'e') {
        lane = 'E';
    }
    else if (lane == 'r') {
        lane = 'R';
    }
    else if (lane != 'E') {
        if (lane != 'R') {
            cout << "Incorrect Input, try again later." << endl;
        }
    }
    q.enqueue(1, 10, 20);
    q.dequeue(lane);

    // Check if queue is empty
    if (!q.isEmpty(&q)) {
        success = false;
    }
    if (success) {
        cout << "\033[1;33mSuccessful test\033[0m" << endl;
    }
    else {
        cout << "\033[1;33mThe test was unsuccessful\033[0m" << endl;
    }
}

// testing the printNode function
void TestLine::testPrint() {
    Queue q;
    q.enqueue(1, 10, 20); // e
    q.enqueue(2, 15, 25); // r
    q.enqueue(3, 20, 30); // e
    q.printQueue(&q);
    q.dequeue('E');
    q.dequeue('R');
    q.dequeue('E');

    // Check if queue is empty
    if (!q.isEmpty(&q)) {
        success = false;
    }
    if (success) {
        cout << "\033[1;33mSuccessful test\033[0m" << endl;
    }
    else {
        cout << "\033[1;33mThe test was unsuccessful\033[0m" << endl;
    }
}

// testing if the queue is empty
void TestLine::testIsEmpty() {
    Queue q;
    if (q.isEmpty(&q)) {
        cout << "\033[1;33mSuccessful test, the queue is empty.\033[0m" << endl;
    }
    else {
        success = false;
        cout << "\033[1;33mThe test was unsuccessful.\033[0m" << endl;
    }
}

// testing the store simulation for 24 hours
void TestLine::testLine24Hours() {
    // success is printed in the run app if the minutes that the stores
    // has run for is equal to 1440 minutes
    int n = 60;
    n = n * 24;
    // n should be 1440 here
    runApp(n); 
}


