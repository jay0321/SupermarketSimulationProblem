#include "Queue.h"

Data::Data(int cNum, int sTime, int tTime) {
    this->customerNumber = cNum;
    this->serviceTime = sTime;
    this->totalTime = tTime;
}

Data::~Data() {

}

int Data::getCustNum() {
    return this->customerNumber;
}

int Data::getTotalTime(int currentTime, int servTime, int tTime) {
    if (currentTime == 0) {
        totalTime = 0;
        return this->totalTime;
    }
    totalTime = tTime + servTime + currentTime;
    return this->totalTime;
}

bool Data::isExpress() {
    return (this->serviceTime <= 5);
}

int Data::getExpServiceTime() {
    int serviceTime = 0;
    // Setting the seed for randomization
    std::srand(std::time(nullptr));
    // Randomizing the service time from 1 to 5 minutes
    serviceTime = std::rand() % 5 + 1;
    return serviceTime;
}

int Data::getRegServiceTime() {
    int serviceTime = 0;
    // Setting the seed for randomization
    std::srand(std::time(nullptr));
    // Randomizing the service time from 3 to 8 minutes
    serviceTime = std::rand() % 6 + 3;
    return serviceTime;
}

int Data::setIndex() {
    int index = 0;
    // Setting the seed for randomization
    std::srand(std::time(nullptr));

    // Randomizing a number between 3 and 13 (inclusive)
    index = std::rand() % 10 + 3;
    return index;
}


std::string Data::getItem(int index) {
    if (index < 0 || index >= 16) {
        return "";
    }
    return groceryItems[index];
}