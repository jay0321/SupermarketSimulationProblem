// This is just a test class
// to test that our line 
// full of customers is 
// working properly

class TestLine {
public:
	// tests enqueue
	void testEnqueue();
	// tests dequeue
	void testDequeue();
	// tests print customers entering/ leaving the store
	void testPrint();
	// tests if the queue is empty
	void testIsEmpty();
	// tests the store simulation for 24 hours 
	void testLine24Hours();
private:
	bool success;
};