/**********************************************************/
/*  Programming Assignment Number 5                       */
/*  Description: Deitel and Deitel's supermarket          */
/*  simulation problem                                    */
/*  Date Started: March 4, 2023                           */
/*  Date Finished: March 10, 2023                         */
/**********************************************************/

#ifndef QUEUE_H
#define QUEUE_H

#include "QueueNode.h"
#define _CRT_SECURE_NO_WARNINGS
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <chrono> // these two header files were to help me in building
#include <thread> // the application because they allowed me to slow 
                  // things down

using std::cout;
using std::cin;
using std::endl;

class Queue {
public:
    /*******************************************
    *   Function Name: Queue Constructor        *
    *   Preconditions: None                     *
    *   Postconditions: Empty queue is created  *
    *   Input: None                             *
    *   Description: Initializes the head and   *
    *                tail pointers to null      *
    *******************************************/
    // Constructor to initialize an empty queue
    Queue() : pHead(nullptr), pTail(nullptr) {}
    /*******************************************
    *   Function Name: ~Queue                   *
    *   Preconditions: Queue has been created   *
    *   Postconditions: Memory is deallocated   *
    *   Input: None                             *
    *   Description: Deletes each node in the   *
    *                queue and the data stored  *
    *                in each node.              *
    *******************************************/
    // Destructor to free memory used by the queue
    ~Queue() {
        while (pHead) {
            Node* pTemp = pHead;
            pHead = pHead->getNext();
            delete pTemp->getData();
            delete pTemp;
        }
    }
    /*******************************************
    *   Function Name: enqueue                  *
    *   Preconditions: Queue has been created   *
    *   Postconditions: New node is added to    *
    *                   the back of the queue   *
    *   Input: cNum (customer number), sTime    *
    *          (service time), tTime (total     *
    *          time in the queue)               *
    *   Description: Creates a new node with    *
    *                the given data and adds it *
    *                to the back of the queue.  *
    *******************************************/
    // Add a new element to the back of the queue
    void enqueue(int cNum, int sTime, int tTime);
    /*******************************************
    *   Function Name: dequeue                  *
    *   Preconditions: Queue has been created   *
    *   Postconditions: Front node is removed   *
    *                   from the queue and its  *
    *                   data is returned        *
    *   Input: lane (indicates which queue to   *
    *          remove the node from)            *
    *   Description: Removes the front node     *
    *                from the queue and returns *
    *                the data stored in that    *
    *                node.                      *
    *******************************************/
    // Remove the front element from the queue and return its data
    Data* dequeue(char lane);
    /*******************************************
    *   Function Name: printNode                *
    *   Preconditions: Queue has been created   *
    *   Postconditions: String array is updated *
    *                   with information about  *
    *                   the given node          *
    *   Input: cNum (customer number), sTime    *
    *          (service time), tTime (total     *
    *          time in the queue), lane (which  *
    *          lane the node is in), list (the  *
    *          string array to update)          *
    *   Description: Updates the given string   *
    *                array with information     *
    *                about the given node.      *
    *******************************************/
    // Print a node with given data to a string array
    void printNode(int cNum, int sTime, int tTime, char lane, std::string list[]);
    /*****************************************************************
     * Function Name: printQueue                                     *
     * Preconditions: Queue has been created                         *
     * Postconditions: None                                          *
     * Input: q (a pointer to the queue to print)                    *
     * Description: Prints the contents of the queue to the console. *
     *****************************************************************/
    void printQueue(Queue* q);
    /*******************************************
     * Function Name: isEmpty
     * Preconditions: Queue has been created
     * Postconditions: None
     * Input: q (a pointer to the queue to check)
     * Description: Checks if the queue is empty and returns true if it is, false otherwise.
     *******************************************/
    bool isEmpty(Queue* q);

private:
    Node* pHead;
    Node* pTail;
};

/*************************************************************************************************
 * Function name: runApp(int n);                                                                 *
 * This function runs the simulation of the grocery store queue for a given number of minutes.   *
 * Input:                                                                                        *
 *   n: an integer representing the number of minutes to run the simulation for.                 *
 * Output:                                                                                       *
 *   None. However, the function prints out information about the customers who enter and exit   *
 *   the two queues during the simulation.                                                       *
 * Preconditions:                                                                                *
 *   None.                                                                                       *
 * Postconditions:                                                                               *
 *   None.                                                                                       *
 * Side effects:                                                                                 *
 *   - Two Queue objects are created to represent the express lane and the regular lane.         *
 *   - Node objects are added to and removed from the two queues during the simulation.          *
 *   - Customer numbers and total service times are incremented and updated for each node added  *
 *     to the two queues.                                                                        *
 *   - Memory is allocated and deallocated for Data objects used to initialize new nodes.        *
 * Complexity:                                                                                   *
 *   O(n), where n is the number of minutes to run the simulation for.                           *
 **************************************************************************************************/
void runApp(int n);
#endif

