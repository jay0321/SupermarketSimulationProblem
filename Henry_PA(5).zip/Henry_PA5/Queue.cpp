#include "Queue.h"

void Queue::enqueue(int cNum, int sTime, int tTime) {
    Data* pData = new Data{ cNum, sTime, tTime};
    Node* pNewNode = new Node{ pData, nullptr };
    if (!pHead) {
        // Empty queue, add as first element
        pHead = pTail = pNewNode;
    }
    else {
        // Add to end of non-empty queue
        pTail->setNext(pNewNode);
        pTail = pNewNode;
    }
}

Data* Queue::dequeue(char lane) {
    if (!pHead) {
        // Empty queue, nothing to dequeue
        return nullptr;
    }
    else {
        // Remove first element and return its data
        Node* pTemp = pHead;
        Data* pData = pHead->getData();
        pHead = pHead->getNext();
        if (!pHead) {
            // Queue is now empty, update tail
            pTail = nullptr;
        }
        delete pTemp;
        if (lane == 'E') {
            cout << "\033[1;31mCustomer " << pData->getCustNum() << " has exited the express line.\033[0m" << endl; // Print message
        }
        else if (lane == 'R') {
            cout << "\033[1;34mCustomer " << pData->getCustNum() << " has exited the regular line.\033[0m" << endl; // Print message
        }
        return pData;
    }
}

void Queue::printNode(int cNum, int sTime, int tTime, char lane, std::string list[]) {
    if (lane == 'E') {
        // using ansi codes here to print express lane
        // data in bold red
        cout << "\033[1;31mExpress Lane:\t\tGroceryList:" << endl;
        cout << "Customer " << cNum << "\t\t1) " << list[0] << endl;
        cout << "Service time: " << sTime << "\t\t2) " << list[1] << endl;
        cout << "Total time: ";
        cout << tTime;
        // format checking for big vals
        if (tTime > 100) {
            cout << "\t3) ";
            cout << list[2];
        }
        // two tabs for smaller values and one tab for bigger values
        else if (tTime < 100) {
            cout << "\t\t3) ";
            cout << list[2];
        }
        // end of color
        cout << "\033[0m" << endl;
        cout << endl;
    }
    // printing in blue for regular lane
    else if (lane == 'R') {
        cout << "\033[1;34mRegular Lane:\t\tGroceryList:" << endl;
        cout << "Customer " << cNum << "\t\t1) " << list[0] << endl;
        cout << "Service time: " << sTime << "\t\t2) " << list[1] << endl;
        cout << "Total time: ";
        cout << tTime;
        // format checking for big vals
        if (tTime > 100) {
            cout << "\t3) ";
            cout << list[2];
        }
        // two tabs for smaller values and one tab for bigger values
        else if (tTime < 100) {
            cout << "\t\t3) ";
            cout << list[2];
        }
        // end of color
        cout << "\033[0m" << endl;
        cout << endl;
    }
}

void Queue::printQueue(Queue* q) {
    Node* pNode = q->pHead;
    if (pNode == nullptr) {
        cout << "Queue is empty." << endl;
        return;
    }
    cout << "Customers in line:" << endl;
    while (pNode != nullptr) {
        Data* pData = pNode->getData();
        cout << "Customer " << pData->getCustNum() << endl;
        pNode = pNode->getNext();
    }
}

bool Queue::isEmpty(Queue* q) {
    int success = 1;
    if (q == nullptr) {
        success = 0;
        return success;
    }
    return success;
}
