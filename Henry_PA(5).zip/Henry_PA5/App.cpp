#include "Queue.h"

void runApp(int n) {
    std::string gList[3];
    char expLane = 'E';
    char regLane = 'R';
    // minutes the program has run for
    int minRan = 0;
    // number of minutes for an express lane customer
    int expRand = 0;
    // number of minutes for a regular lane customer
    int rand = 0;

    // Create two queues, one for the express lane and one for the regular lane
    Queue expressLane;
    Queue regularLane;

    // Customer numbers for each lane
    int expressCustNum = 1;
    int regularCustNum = 1;
    int expTotalTime = 0;
    int regTotalTime = 0;
    int index = 0;
    while (minRan != n) {
        // Add a new customer to the express lane
        Data* expData = new Data(expressCustNum, expRand, expTotalTime);
        expressLane.enqueue(expData->getCustNum(), expData->getExpServiceTime(), expTotalTime);
        expTotalTime = expData->getTotalTime(minRan, expData->getExpServiceTime(), expTotalTime);
        // print Node here
        // set indices for grocery list items
        index = expData->setIndex();
        gList[0] = expData->getItem(index);
        gList[1] = expData->getItem(index + 1);
        gList[2] = expData->getItem(index + 2);
        expressLane.printNode(expData->getCustNum(), expData->getExpServiceTime(), expTotalTime, 'E', gList);
        // Add a new customer to the regular lane
        Data* regData = new Data(regularCustNum, rand, regTotalTime);
        regularLane.enqueue(regData->getCustNum(), regData->getRegServiceTime(), regTotalTime);
        // iterations called, random int 3-8,            
        regTotalTime = regData->getTotalTime(minRan, regData->getRegServiceTime(), regTotalTime);
        // print cases here 
        // set 3 indices for grocery list items
        index = regData->setIndex();
        gList[0] = regData->getItem(index - 1);
        gList[1] = regData->getItem(index - 2);
        gList[2] = regData->getItem(index  - 3);
        regularLane.printNode(regData->getCustNum(), regData->getExpServiceTime(), regTotalTime, 'R', gList);
        // Increment customer numbers for each lane
        expressCustNum++;
        regularCustNum++;

        minRan++;
        // this is to slow our function down and utilize a truer
        // randomization for our grocery list
        if (n < 10) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        // Deallocate memory for Data objects
        delete expData;
        delete regData;
        expressLane.dequeue(expLane);
        regularLane.dequeue(regLane);
        cout << endl;
        // sleeping again for customers exiting
        if (n < 20) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
    // printing successfull for 24 hours
    if (minRan == 1440) {
        cout << "\033[1;33mSuccessful test \033[0m" << endl << endl;
    }
}
