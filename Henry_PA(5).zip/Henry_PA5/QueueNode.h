// A queueNode is a customer
#include "Data.h"

class Node {
public:
    // constructor function
    Node(Data* pData, Node* pNext) : pData(pData), pNext(pNext) {}
    // get function
    Data* getData();
    // get function
    Node* getNext();
    // set function
    void setNext(Node* pNext);
private:
    Data* pData;
    Node* pNext;
}; // add semicolon here

