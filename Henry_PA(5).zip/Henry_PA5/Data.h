// This is the data contained inside
// one of the queueNodes, must 
// allocate space for the Node and 
// the Data when making a new Node, 
// must free() the Data and the
// Node separately

#include <string>

class Data {
public:
    /******************************************************************************
    * Function Name : Data Construction                                           *
    * Preconditions : None                                                        *
    * Postconditions : Data object has been created                               *
    * Input : cNum(customer number), sTime(service time), tTime(total time)       *
    * Description : Constructor for Data class that initializes member variables. *
    *******************************************************************************/
    Data(int cNum, int sTime, int tTime);
    /******************************************************************************
    * Function Name : Data Destruction                                            *
    * Preconditions : None                                                        *
    * Postconditions : Data object has been destroyed                             *
    * Input :                                                                     *
    * Description : Destructor for Data class that initializes member variables.  *
    *******************************************************************************/
    ~Data();
    /******************************************************************************
    * Function Name : getCustNum                                                  *
    * Preconditions : Customer node has been enqueued                             *
    * Postconditions : Returns int                                                *
    * Input : None                                                                *
    * Description : Getter function for the customer number private variable mem  *
    *******************************************************************************/
    int getCustNum();
    /******************************************************************************
    * Function Name : getTotalTime                                                *
    * Preconditions : Customer node has been enqueued                             *
    * Postconditions : Returns int                                                *
    * Input : cNum(customer number), sTime(service time), tTime(total time)       *
    * Description : Getter function for the total time a store has been running   *
    *******************************************************************************/
    int getTotalTime(int currentTime, int servTime, int tTime);
    /******************************************************************************
    * Function Name : isExpress                                                   *
    * Preconditions : Customer node has been enqueued                             *
    * Postconditions : Returns bool                                               *
    * Input : None                                                                *
    * Description : Makes sure that the number generated is less than or = to 5   *
    *******************************************************************************/
    bool isExpress();
    /******************************************************************************
    * Function Name : getExpServiceTime                                           *
    * Preconditions : Customer node has been enqueued                             *
    * Postconditions : Returns int                                                *
    * Input : None                                                                *
    * Description : Generates a number between 1 and 5 for the express lane queue *
    *******************************************************************************/
    int getExpServiceTime();
    /******************************************************************************
    * Function Name : getRegServiceTime                                           *
    * Preconditions : Customer node has been enqueued                             *
    * Postconditions : Returns int                                                *
    * Input : None                                                                *
    * Description : Generates a number between 3 and 8 for the regular lane queue *
    *******************************************************************************/
    int getRegServiceTime();
    /******************************************************************************
   * Function Name : setIndex                                                    *
   * Preconditions : Customer node has been enqueued                             *
   * Postconditions : Returns int                                                *
   * Input : None                                                                *
   * Description : Generates a random number to give to the customer as a grocery*
   *    list item in the predetermined list of groceries in the private mems     *
   *******************************************************************************/
    int setIndex();
    /******************************************************************************
   * Function Name : setIndex                                                    *
   * Preconditions : The index has been set                                      *
   * Postconditions : Returns string                                             *
   * Input : None                                                                *
   * Description : Returns the items on the grocery list that were randomly      *
   * generated                                                                   *
   *******************************************************************************/
    std::string getItem(int index);
private:
    int customerNumber;
    int serviceTime;
    int totalTime;
    std::string groceryItems[15] = { "Coffee Grounds", "Milk", "Bread", "Seasoning", "Steaks", "Pineapple", "Creamer", "Chicken", "Ground Beef", "Salad", "Tomatoes", "Onions", "Celantro", "Beans", "Mayo" };
};
