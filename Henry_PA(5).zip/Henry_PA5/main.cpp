#include "Queue.h"
#include "testLine.h"

// This is the entry point of our code
int main(void) {
	cout << "\033[38;5;75mDeitel and Deitel's Supermarket Simulation\033[0m" << endl << endl;
	TestLine test;
	int choice = 0;
	int n = 0;
	while (choice != 7) {
		cout << "1) Test Enqueue" << endl;
		cout << "2) Test Dequeue" << endl;
		cout << "3) Test Print" << endl;
		cout << "4) Test 24 Hours" << endl;
		cout << "5) Run by n Iterations" << endl;
		cout << "6) Clear the screen" << endl;
		cout << "7) Exit" << endl;
		cin >> choice;
		switch (choice) {
		case 1:
			// test enqueue here
			test.testEnqueue();
			break;
		case 2:
			// test dequeue here 
			test.testDequeue();
			break;
		case 3:
			// test print queue here 
			test.testPrint();
			break;
		case 4:
			// test 24 hour line simulation here
			test.testLine24Hours();
			break;
		case 5:
			// run by n iterations here
			cout << "Enter the number of iterations to run the program for:" << endl;
			cin >> n;
			runApp(n);
			break;
		case 6:
			// clear the screen here 
			system("cls");
			break;
		case 7:
			exit(0);
		}
	}
	return 0;
}
