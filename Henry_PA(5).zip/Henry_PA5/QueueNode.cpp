#include "Queue.h"

Data* Node::getData() {
	return this->pData;
}

Node* Node::getNext() {
	return this->pNext;
}

void Node::setNext(Node* nextNode) {
	this->pNext = nextNode;
}
